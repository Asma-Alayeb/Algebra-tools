function solve() {
let a = parseFloat(document.getElementById('a').value);
let b = parseFloat(document.getElementById('b').value);
let x = -b/a;
document.getElementById('result').innerText = "Solution x = " + x;
}
